import io.restassured.*;
import static io.restassured.RestAssured.*;

public class GetBookingByID {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RestAssured.baseURI=("https://restful-booker.herokuapp.com/booking/1297");
		given();
		when().get()
		.then()
		.log().all().assertThat().statusCode(200);
		
	}

}
