import io.restassured.*;
import static io.restassured.RestAssured.*;


public class CreateBooking {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://restful-booker.herokuapp.com";
        given().log().all().header("Content-Type","application/json")
        .body("{\r\n"
        		+ "    \"firstname\": \"Devesh\",\r\n"
        		+ "    \"lastname\": \"Dutta\",\r\n"
        		+ "    \"totalprice\": 601,\r\n"
        		+ "    \"depositpaid\": true,\r\n"
        		+ "    \"bookingdates\": {\r\n"
        		+ "        \"checkin\": \"2023-05-12\",\r\n"
        		+ "        \"checkout\": \"2023-05-23\"\r\n"
        		+ "    },\r\n"
        		+ "    \"additionalneeds\": \"Breakfast\"\r\n"
        		+ "}")
        .when().post("/booking")
        .then().log().all().assertThat().statusCode(200);
	
	}

}
