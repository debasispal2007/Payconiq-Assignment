import io.restassured.*;
import static io.restassured.RestAssured.*;

public class CreateToken {

	public static void main(String[] args) {


		RestAssured.baseURI="https://restful-booker.herokuapp.com";
        given().log().all().header("Content-Type","application/json")
        .body("{\r\n"
        		+ "    \"username\" : \"admin\",\r\n"
        		+ "    \"password\" : \"password123\"\r\n"
        		+ "}")
        .when().post("/auth")
        .then().log().all().assertThat().statusCode(200);		
		
	}

}
