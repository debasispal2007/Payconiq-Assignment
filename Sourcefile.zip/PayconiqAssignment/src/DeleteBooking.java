import io.restassured.RestAssured;
public class DeleteBooking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestAssured
		.given()
				.baseUri("https://restful-booker.herokuapp.com/booking/779")
				.cookie("token", "a1ec982bbe16357")
		.when()
				.delete()
		.then().log().all()
				.assertThat()
				.statusCode(201);

			
	}

}
