import org.hamcrest.Matchers;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PartialUpdate {

	public static void main(String[] args) {

				String jsonString = "{\r\n" + 
						"    \"firstname\" : \"Natalie\",\r\n" + 
						"    \"lastname\" : \"Jose\"}";

				RestAssured
					.given()
							.baseUri("https://restful-booker.herokuapp.com/booking/716")
							.cookie("token", "67edefdc469127e")
							.contentType(ContentType.JSON)
							.body(jsonString)
					.when()
							.patch()
					.then()
					.log().all().assertThat().statusCode(200)
							.body("firstname", Matchers.equalTo("Natalie"))
							.body("lastname", Matchers.equalTo("Jose"));
		 
	}

}
